# KuCoin Perpetual Futures Dashboard V3.4

**Professional Semi-Automated Trading System with Signal Generator**

---

## 🎯 Version 3.4 - Critical Fixes

### ✅ Fix 1: Dollar-Based Position Sizing with Leverage
**Problem (V3.3):** Position size was calculated in lots without clear dollar value display.

**Solution (V3.4):**
- **Margin Used**: Actual USDT from your account (e.g., $50 = 0.5% of $10,000)
- **Position Value**: Total exposure with leverage (e.g., $500 = $50 margin × 10x leverage)
- **Clear Logging**: Shows both margin and total exposure

**Example:**
```
Account Balance: $10,000
Position %: 0.5%
Leverage: 10x

V3.3 (unclear):
  Size: 5 lots

V3.4 (clear):
  Size: 5 lots ($500 @ 10x)
  Margin Used: $50
  Total Exposure: $500
```

### ✅ Fix 2: Leveraged P&L Percentages for TP/SL Logic
**Problem (V3.3):** Break-even and trailing stop used price movement %, not leveraged profit %.

**Critical Issue:**
- At 10x leverage, a 0.2% price move = 2% profit on YOUR capital
- V3.3 break-even triggered at 0.001% PRICE movement (way too early!)
- V3.3 trailing stop used price % instead of leveraged profit %

**Solution (V3.4):**
- **Leveraged P&L %** = (Profit in USDT / Margin Used) × 100
- Break-even triggers correctly at small leveraged gains
- Trailing stop moves based on YOUR actual profit percentage

**Example with 10x Leverage:**
```
Entry: $50,000
Current: $50,100 (0.2% price movement)
Position: $10,000 (1,000 lots @ 10x)
Margin: $1,000

V3.3 (WRONG):
  P&L %: 0.2% (just price movement)
  Break-even: Triggered at 0.001% price move ❌
  
V3.4 (CORRECT):
  P&L: $100 profit
  Leveraged P&L %: ($100 / $1,000) × 100 = 10% ✅
  Break-even: Triggers at ~0.001% leveraged gain
  Trailing: Moves every 0.15% leveraged profit gain
```

---

## 📦 Installation

### Prerequisites
- Node.js 16+ ([Download](https://nodejs.org))
- KuCoin Futures account with API credentials

### Quick Start

1. **Clone/Extract Files**
```bash
cd kucoin-futures-dashboard
```

2. **Create .env File**
```bash
cp .env.example .env
nano .env  # Edit with your KuCoin API credentials
```

Required credentials:
```env
KUCOIN_API_KEY=your_api_key_here
KUCOIN_API_SECRET=your_api_secret_here
KUCOIN_API_PASSPHRASE=your_api_passphrase_here
```

3. **Run Startup Script**
```bash
chmod +x start.sh
./start.sh
```

Or manually:
```bash
npm install
node server.js
```

4. **Open Dashboard**
```
http://localhost:3001
```

---

## 💰 Trading Configuration

### Position Sizing (V3.4 Enhanced)
```javascript
POSITION_SIZE_PERCENT: 0.5%  // 0.5% of account equity per trade
DEFAULT_LEVERAGE: 10x        // Default leverage multiplier

Example with $10,000 account:
- Margin Used: $50 (0.5% of $10,000)
- Position Value: $500 (10x leverage)
- Lots: Calculated automatically
```

### Risk Management
```javascript
INITIAL_SL_PERCENT: 0.5%      // Stop loss (0.5% price movement)
INITIAL_TP_PERCENT: 2.0%      // Take profit (2% price movement)
BREAK_EVEN_TRIGGER: 0.001%    // Lock break-even at any leveraged profit
TRAILING_STEP_PERCENT: 0.15%  // Trail every 0.15% leveraged profit
TRAILING_MOVE_PERCENT: 0.05%  // Move SL by 0.05% price
```

**Important:** Break-even and trailing now use LEVERAGED percentages!

---

## 🔧 Technical Details

### V3.4 Code Changes

**1. Position Sizing Calculation**
```javascript
// Margin used (actual USDT risk)
const marginUsed = accountBalance * (positionSizePercent / 100);

// Position value with leverage (total exposure)
const positionValueUSD = marginUsed * leverage;

// Convert to lots
const size = Math.floor(positionValueUSD / (entryPrice * multiplier));
```

**2. Leveraged P&L Calculation**
```javascript
// Price difference in USDT
const priceDiff = side === 'long' 
  ? (currentPrice - entryPrice)
  : (entryPrice - currentPrice);

// P&L in USDT
const unrealizedPnl = priceDiff * size * multiplier;

// LEVERAGED P&L % (on YOUR capital, not position value)
const unrealizedPnlPercent = (unrealizedPnl / marginUsed) * 100;
```

---

## 📊 Features

### Core Functionality
- ✅ **8 Technical Indicators**: RSI, MACD, Williams %R, Stochastic, Bollinger Bands, ADX, CCI, OBV
- ✅ **Signal Scoring**: -100 to +100 with confidence levels
- ✅ **9th Order Book Level Entry**: Optimal limit order placement
- ✅ **Automated Break-Even Lock**: Risk-free after any profit
- ✅ **Trailing Stop System**: Locks in profits automatically
- ✅ **Multi-Symbol Support**: Monitor up to 10 symbols simultaneously
- ✅ **Position Persistence**: Survives server restarts
- ✅ **Real-Time Updates**: WebSocket-based live data

### Signal Generation
```
HIGH Confidence: Score ≥ 60 or ≤ -60
MEDIUM Confidence: Score 40-59 or -40 to -59
LOW Confidence: Score < 40 and > -40
```

---

## 🚨 Safety & Risk Warnings

### Critical Reminders
- **Test First**: Use KuCoin demo/testnet before live trading
- **Start Small**: Use 0.5% position size initially
- **Leverage Risk**: 10x leverage means 10x gains AND losses
- **Monitor Positions**: System automates exits but you remain responsible
- **API Security**: Never share API credentials, use IP whitelist

### Leverage Examples
```
10x Leverage:
- 1% price move = 10% profit/loss on your capital
- 2% price move = 20% profit/loss
- 5% price move = 50% profit/loss
- 10% price move = 100% profit/loss (liquidation risk)

Risk Management:
- 0.5% SL @ 10x = 5% capital loss maximum
- Position size limits maximum risk per trade
```

---

## 📝 Files Structure

```
kucoin-futures-dashboard/
├── server.js              # Backend (Node.js + Express + WebSocket)
├── public/
│   └── index.html        # Frontend (Single-page dashboard)
├── package.json          # Dependencies
├── .env                  # API credentials (create from .env.example)
├── .env.example          # Template
├── start.sh              # Startup script
├── positions.json        # Auto-created position storage
└── README.md            # This file
```

---

## 🔍 Troubleshooting

### Common Issues

**"Position size too small"**
- Increase position percentage
- Increase leverage
- Check minimum lot size for symbol

**WebSocket won't connect**
- Ensure server is running on port 3001
- Check firewall settings
- Refresh browser page

**API authentication errors**
- Verify credentials in .env
- Check API key permissions (Futures trading enabled)
- Ensure passphrase is correct

**Positions not updating**
- Check KuCoin API status
- Verify symbol contracts are active
- Check account has sufficient margin

---

## 📚 Documentation Links

- [KuCoin Futures API Docs](https://www.kucoin.com/docs/rest/futures-trading/orders/place-order)
- [WebSocket Documentation](https://www.kucoin.com/docs/websocket/basic-info/connect)
- [Technical Indicators Guide](https://www.investopedia.com/technical-analysis-4689657)

---

## 🎓 Support & Contact

### Getting Help
1. Check troubleshooting section above
2. Review console logs for error messages
3. Verify .env configuration
4. Test API connection manually

### Best Practices
- Start with paper trading
- Log all trades for review
- Never risk more than you can afford to lose
- Keep API keys secure
- Monitor positions regularly

---

## ⚖️ License

MIT License - Use at your own risk. Not financial advice.

**Disclaimer:** Cryptocurrency futures trading involves substantial risk of loss. This software is provided as-is without warranty. The developers are not responsible for any financial losses.

---

## 🚀 Version History

### V3.4.0 (Current)
- ✅ Fixed: Position sizing now shows dollar values with leverage
- ✅ Fixed: Break-even and trailing stop use leveraged P&L percentages
- ✅ Enhanced: Clear logging of margin vs total exposure
- ✅ Improved: More accurate P&L calculations

### V3.3
- Last stable version before fixes
- Issue: Lot-based sizing unclear
- Issue: Break-even triggered on price % not leveraged %

---

**Built for professional traders who demand precision and automation.**
