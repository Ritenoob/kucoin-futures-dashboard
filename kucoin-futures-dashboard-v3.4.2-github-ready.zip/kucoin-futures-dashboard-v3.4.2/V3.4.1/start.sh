#!/bin/bash
# ============================================================================
# KuCoin Futures Dashboard - Startup Script
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     KuCoin Perpetual Futures Dashboard v3.4.1                ║"
echo "║     Semi-Automated Trading System                            ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check Node.js
echo -e "${BLUE}[1/4] Checking Node.js...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js is not installed${NC}"
    echo "Please install Node.js from: https://nodejs.org"
    exit 1
fi
NODE_VERSION=$(node -v)
echo -e "${GREEN}✓ Node.js ${NODE_VERSION}${NC}"

# Check npm
echo -e "${BLUE}[2/4] Checking npm...${NC}"
if ! command -v npm &> /dev/null; then
    echo -e "${RED}✗ npm is not installed${NC}"
    exit 1
fi
NPM_VERSION=$(npm -v)
echo -e "${GREEN}✓ npm v${NPM_VERSION}${NC}"

# Check .env file
echo -e "${BLUE}[3/4] Checking configuration...${NC}"
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        echo -e "${YELLOW}Creating .env from .env.example...${NC}"
        cp .env.example .env
        echo -e "${YELLOW}⚠ Please edit .env and add your KuCoin API credentials${NC}"
        echo ""
        echo "Required fields:"
        echo "  KUCOIN_API_KEY=your_api_key"
        echo "  KUCOIN_API_SECRET=your_api_secret"
        echo "  KUCOIN_API_PASSPHRASE=your_passphrase"
        echo ""
        read -p "Press Enter after editing .env file..."
    else
        echo -e "${RED}✗ No .env or .env.example file found${NC}"
        exit 1
    fi
fi

# Check if API keys are set
if grep -q "your_api_key_here" .env 2>/dev/null; then
    echo -e "${RED}✗ Please set your actual API credentials in .env${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Configuration found${NC}"

# Install dependencies
echo -e "${BLUE}[4/4] Installing dependencies...${NC}"
npm install --silent
echo -e "${GREEN}✓ Dependencies installed${NC}"

# Kill any existing process on port 3001
if lsof -Pi :3001 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}Stopping existing server on port 3001...${NC}"
    kill $(lsof -Pi :3001 -sTCP:LISTEN -t) 2>/dev/null || true
    sleep 1
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  Starting server...                                          ║"
echo "║  Dashboard will be available at: http://localhost:3001       ║"
echo "║  Press Ctrl+C to stop                                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Start server
node server.js
