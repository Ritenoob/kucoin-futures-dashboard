# Security Notes

## Do not commit secrets
This project uses a local `.env` file for KuCoin API credentials.

- Never commit `.env` to Git.
- Use `.env.example` as the template.

## If you ever pushed secrets to GitHub
If an API key, secret, or passphrase was committed to any branch (even briefly), rotate it immediately in your KuCoin account and treat it as compromised.
